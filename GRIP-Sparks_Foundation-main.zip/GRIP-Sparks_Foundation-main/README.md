# GRIP-Sparks_Foundation
## Task1- Basic Banking System

### **Introduction** -
A dynamic banking website permitting transfer of money between multiple users.

## Technologies Used-
### Front-End
* HTML
* CSS
* JavaScript

### Back-End
* PHP

### Database
* MySQL

### Flow of website
Home> View Customers> Transfer Money> Select customer to transfer to >Transaction History

Database name- mno_bank  
Tables- all_users, transaction_history, subscribers
